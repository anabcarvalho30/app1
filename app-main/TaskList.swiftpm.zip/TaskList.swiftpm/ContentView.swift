import SwiftUI
import SwiftData

struct ContentView: View {
    
    //Quando você quer alterar algo dentro da View, você usa o @State.
    
    @State var title = ""
    
    @State var category_name: String = ""
    
    @State var category_color: Color = Color.secondary
    
    @State var isShowingSheetTask: Bool = false
    @State var isShowingSheetCategory: Bool = false
    @State var isShowingSheetCategoryToTask: Bool = false
    @State var isShowingAlertToDeleteCategory: Bool = false
    
    @Environment(\.modelContext) var modelContext
    
    @Query var tasks: [Task]
    
    //Mudando o taskDoneCount, que está fora do escopo da função.
    func countTasksDone (tasks: [Task]) ->(dones: Int, notDones: Int) {
        var taskDoneCount: Int = 0
        var taskNotDoneCount: Int = 0
        taskDoneCount = tasks.filter { task in task.isDone }.count
        taskNotDoneCount = tasks.count - taskDoneCount
        return (dones: taskDoneCount, notDones: taskNotDoneCount)
    }
    
    @Query var categories : [Category]
    
    @State var taskSelected : Task = Task(title:"", date:.now)
    
//    @State var tasksFilter = tasks.filter ({
//        return $0.category.id == categorySelected.id
//    })
    
    @State var isBtnVsbl : Bool = true
    
    @State private var isDarkMode = false
    
    //Mudar os nomes das categorias.
    let categorias : [Category] = [Category(name: "Alimentação", color: .blue), Category(name: "Limpeza", color: .green), Category(name: "Higiene", color: .yellow)]
    
    let Marrom = Color(red: 0.6392, green: 0.0078, blue: 0)
    
    var body: some View {
        Text("Lista de Compras")
            .foregroundColor(Marrom)
            .font(.largeTitle)
            .fontWeight(.bold)
        if categories.isEmpty{
            if isBtnVsbl{
                Button{
                    for categoria in categorias{
                        modelContext.insert(categoria)
                        isBtnVsbl = false
                    }
                } label: {
                    Text("Adicionar as Categorias-Padrão       ").foregroundColor(Marrom)
                }
                .buttonStyle(.bordered)
                .foregroundColor(.white)
                .background(.quaternary)
                .cornerRadius(5)

            }
        }
     
        List{
            //Usando o cifrão($) para conetar com uma variável State!
            Toggle("Modo escuro", isOn: $isDarkMode)
                .toggleStyle(SwitchToggleStyle(tint: Color(.red)))
            
            Section{
            } header: {
                HStack{
                    Text("Criar nova compra")
                    Button{
                        isShowingSheetTask = true
                    }label: {
                        Spacer()
                        Image(systemName: "plus")
                    }
                }
            }
            
            Section{
            }header: {
                HStack{
                    Text("Criar nova Categoria")
                    Button{
                        isShowingSheetCategory = true
                    }label: {
                        Spacer()
                        Image(systemName: "plus")
                    }
                }
            }
            
            Section{
                ForEach(categories){ categ in
                    CategoryView(category: categ).swipeActions(edge: .trailing, allowsFullSwipe: false){
                            Button(role: .destructive){
                                if !tasks.contains(where: {$0.category == categ}){
                                    modelContext.delete(categ)
                                }else{
                                    isShowingAlertToDeleteCategory = true
                                }
                            } label: {
                                Image(systemName: "trash")
                            }
                    }
                }
                .alert(isPresented: $isShowingAlertToDeleteCategory){
                    Alert(title: Text("Falha ao deletar categoria"), message: Text("Não foi possível deletar esta categoria, visto que há um produto associada a ela."), dismissButton: .default(Text("Ok")))
                }
            }
            header: {
                HStack{
                    Text("Categorias")
                }
            } footer: {
                HStack{
                    Text("Total de Categorias: \(categories.count)")
                }
            }
            .onAppear {
                print(categories.count)
            }
            
            Section{
                ForEach(tasks){ task in
                        TaskView(task).swipeActions(edge: .trailing, allowsFullSwipe: false){
                            //Botão de delete.
                            Button(role: .destructive){
                                modelContext.delete(task)
                            } label: {
                                Image(systemName: "trash")
                            }
                            Button{
                                isShowingSheetCategoryToTask = true
                                taskSelected = task
                            } label: {
                                Image(systemName: "ellipsis")
                            }.tint(.blue)
                            //Botão de adicionar categoria.
                        }
                    }
            }
            header: {
                HStack{
                    Text("Compras a fazer: \(countTasksDone(tasks: tasks).notDones)")
                    Spacer()
                    Text("Lista de Compras")
                        .font(.system(size: 20))
                        .fontWeight(.bold)
                    Spacer()
                    Text("Compras feitas:\(countTasksDone(tasks: tasks).dones)")
                }
            }
        }
        
        .preferredColorScheme(isDarkMode ? .dark : .light)
        .environment(\.colorScheme, isDarkMode ? .dark : .light)
        .animation(.interpolatingSpring(stiffness: 20, damping: 5), value: isDarkMode)
        
        .sheet(isPresented: $isShowingSheetTask){
            AddTaskView(isShowing: $isShowingSheetTask)
        }
        .sheet(isPresented: $isShowingSheetCategory){
            AddCategoryView(isShowing: $isShowingSheetCategory)
        }
        .sheet(isPresented: $isShowingSheetCategoryToTask){
            AddCategoryToTaskView(taskSelected: $taskSelected)
        }
    }
}

//Variável Binding pressedTaskToCategory significa a task que você estava apertando quando abriu a aba de AddCategoryToTaskView.
//A sheet addCategoryToTaskView foi feita para que voce possa adicionar uma categoria a uma task
//Foram feitas alteracoes na taskview para mostrar a categoria dela.
